# APLIKASI MANAJEMEN ANGGOTA

Assalamualaikum Wr. Wb
Halo semuanya nama saya Fadhlurrahman
Saya membuat aplikasi manajemen anggota berbasis web dengan teknologi codeigniter 4

berikut cara instalasinya

### 1. DOWNLOAD ZIP
silahkan ke code kemudian download zip kemudian buat folder anggota-master di htdocs kemudian ekstrak.
 
### 2. UPLOAD KE DATABASE
jalankan xampp anda kemudian pergi ke localhost/phpmyadmin kemudian silahkan buat database baru dengan nama anggota_master kemudian import database di folder yg ditaruh di htdocs
dengan nama file : `anggota_master.sql`

### 3. KONFIGURASI
silahkan buka folder tersebut di code editor kesayangan kalian kemudian pergi ke folder .env 
kemudian atur

<!-- JIKALAU DI XAMPP -->

`database.default.hostname = localhost
database.default.database = anggota_master
database.default.username = root
database.default.password = `

jikalau anda sudah mengubah username atau passwordny silahkan disesuaikan, Terimakasih :)
jangan lupa di star hehe.

Semoga Bermanfaat, Dan Happy Coding!
